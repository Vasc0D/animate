"use client";
import { useSearchParams } from "next/navigation";

export default function ResultadoPage() {
  const searchParams = useSearchParams();
  const puntaje = parseInt(searchParams.get("puntaje")) || 0;
  const nivel = searchParams.get("nivel") || "Desconocido";

  const porcentaje = Math.min((puntaje / 20) * 100, 100);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-white to-blue-100 text-black p-6">
      <h1 className="text-5xl font-bold text-center mb-6">🎉 ¡Test Completado! 🎉</h1>

      <div className="bg-white p-8 rounded-xl shadow-lg text-center w-full max-w-md">
        <p className="text-2xl mb-2">Tu <strong>puntaje</strong> es:</p>
        <p className="text-4xl font-bold text-green-600 mb-4">{puntaje} / 20</p>

        <p className="text-2xl mb-2">Te corresponde el <strong>nivel</strong>:</p>
        <p className="text-4xl font-bold text-blue-700 mb-6">Nivel {nivel}</p>

        <div className="w-full bg-gray-200 h-6 rounded-full overflow-hidden mb-4">
          <div
            className="bg-green-500 h-full"
            style={{ width: `${porcentaje}%`, transition: "width 1s" }}
          ></div>
        </div>

        <p className="text-sm text-gray-500">Progreso del test: {porcentaje.toFixed(0)}%</p>
      </div>
    </div>
  );
}
