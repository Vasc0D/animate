"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function TestDiagnostico() {
  const [preguntas, setPreguntas] = useState([]);
  const [respuestas, setRespuestas] = useState([]);
  const router = useRouter();

  const email = typeof window !== 'undefined' ? localStorage.getItem("email") : null;

  useEffect(() => {
    fetch("http://localhost:5001/test/fracciones")
      .then((res) => res.json())
      .then((data) => {
        setPreguntas(data.preguntas || []);
        setRespuestas(new Array(data.preguntas.length).fill(""));
      });
  }, []);

  const handleChange = (index, value) => {
    const nuevasRespuestas = [...respuestas];
    nuevasRespuestas[index] = value;
    setRespuestas(nuevasRespuestas);
  };

  const handleSubmit = async () => {
    const res = await fetch("http://localhost:5001/test/fracciones/resultados", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, respuestas }),
    });
    const data = await res.json();
    router.push(`/fracciones/resultado?puntaje=${data.puntaje}&nivel=${data.nivel}`);

  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Test Diagnóstico de Fracciones</h1>
      {preguntas.map((pregunta, index) => (
        <div key={index} className="mb-4">
          <p className="mb-2">{index + 1}. {pregunta.enunciado}</p>
          <input
            type="text"
            value={respuestas[index]}
            onChange={(e) => handleChange(index, e.target.value)}
            className="border rounded px-3 py-1 w-full"
            placeholder="Escribe tu respuesta... ej. 3/4"
          />
        </div>
      ))}

      <button
        onClick={handleSubmit}
        className="bg-blue-600 text-white px-4 py-2 rounded mt-4"
      >
        Enviar respuestas
      </button>
    </div>
  );
}
